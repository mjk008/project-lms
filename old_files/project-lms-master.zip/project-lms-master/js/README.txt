The js folder holds all the JavaScript files used by the LMS.
