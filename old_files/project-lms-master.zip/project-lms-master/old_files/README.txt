This folder contains all the files used for the previous design. 
