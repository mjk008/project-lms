This folder contains all the CSS files required for the Learning Mangement System.
Copyrights. Mind Labs. Udam Liyanage.
