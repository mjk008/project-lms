This folder has all the PHP files associated with the Learning Mangement System. 
All the classes used is also stored here. 
