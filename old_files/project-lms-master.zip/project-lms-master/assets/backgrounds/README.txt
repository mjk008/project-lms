Folder holds background images used by the LMS.
