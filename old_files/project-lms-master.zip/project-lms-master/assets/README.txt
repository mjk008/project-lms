The assests folder is used to store all the graphics and/or animations used by the system.
